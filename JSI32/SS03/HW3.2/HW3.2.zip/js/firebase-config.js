const firebaseConfig = {
  apiKey: "AIzaSyAd5M_vkWugvTQ4p3Z4rPKkpcX4JkJ7jXw",
  authDomain: "coffee-management-92dca.firebaseapp.com",
  projectId: "coffee-management-92dca",
  storageBucket: "coffee-management-92dca.firebasestorage.app",
  messagingSenderId: "348523963586",
  appId: "1:348523963586:web:721b88f07f56f8e0ce475b",
  measurementId: "G-KPBRG7MJM8"
};



firebase.initializeApp(firebaseConfig);
console.log(firebase.app().name);