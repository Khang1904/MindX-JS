document.getElementById("start-quiz").addEventListener("click",() => {
    window.location.href = "quiz.html";
});